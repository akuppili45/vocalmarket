**To delete a client certificate**

Command::

  aws apigateway delete-client-certificate --client-certificate-id a1b2c3
